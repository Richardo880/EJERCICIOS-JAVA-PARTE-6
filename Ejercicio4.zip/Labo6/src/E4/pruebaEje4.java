
import java.util.Scanner;

public class pruebaEje4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        eje4 e4 = new eje4();
        int n = -1;
        
        //A)
        while(n < 0){
            System.out.print("Ingrese un numero POSITIVO que quiera calcular en la serie Fibonacci: ");
            n = sc.nextInt();
        }
        System.out.println("\nEl numero de Fibonacci de "+n+" es "+e4.fibonacci(n));
        /* B)
           El número de Fibonacci más grande que puede imprimirse en este sistema es 1836311903 que corresponde al numero 46
           los numeros superiores a 46 superan el valor maximo del tipo de dato int y por ello se muestra como un numero negativo
        */
        
        //C)
        double nd = -1;
        while(nd < 0){
            System.out.print("\nIngrese un numero POSITIVO (puede ser un numero con decimales) que quiera calcular en la serie Fibonacci: ");
            nd = sc.nextDouble();
        }
        System.out.println("\nEl numero de Fibonacci de "+nd+" es "+e4.fibonacciDouble(nd));
        /*
            El número de Fibonacci más grande que puede imprimirse en este sistema es 1.3069892237633987E308 que corresponde al numero 1476
            los numeros superiores a 1476 dan como resultado "infinito"
        */
    }
}
