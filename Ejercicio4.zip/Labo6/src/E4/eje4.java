
public class eje4 {

    public int fibonacci(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }

        int[] f = new int[n + 1];
        int i;
        f[0] = 0;
        f[1] = 1;
        for (i = 2; i <= n; i++) {
            f[i] = f[i - 1] + f[i - 2];
        }
        return f[n];
    }

    public double fibonacciDouble(double n) {
        if (n == 0) {
            return 0.0;
        }
        if (n == 1) {
            return 1.0;
        }

        double[] f = new double[(int) n + 1];
        int i;
        f[0] = 0.0;
        f[1] = 1.0;
        for (i = 2; i <= n; i++) {
            f[i] = f[i - 1] + f[i - 2];
        }
        return f[(int) n];
    }
}
