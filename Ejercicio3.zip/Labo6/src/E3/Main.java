package E3;

import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Arreglo arr = new Arreglo();
        Random r = new Random();
        int low = 10;
        int high = 100;

        arr.sumVal(1, 1, r.nextInt(high - low) + low);
        arr.sumVal(2, 1, r.nextInt(high - low) + low);
        arr.sumVal(3, 1, r.nextInt(high - low) + low);
        arr.sumVal(4, 1, r.nextInt(high - low) + low);
        arr.sumVal(5, 1, r.nextInt(high - low) + low);

        arr.sumVal(1, 2, r.nextInt(high - low) + low);
        arr.sumVal(2, 2, r.nextInt(high - low) + low);
        arr.sumVal(3, 2, r.nextInt(high - low) + low);
        arr.sumVal(4, 2, r.nextInt(high - low) + low);
        arr.sumVal(5, 2, r.nextInt(high - low) + low);

        arr.sumVal(1, 3, r.nextInt(high - low) + low);
        arr.sumVal(2, 3, r.nextInt(high - low) + low);
        arr.sumVal(3, 3, r.nextInt(high - low) + low);
        arr.sumVal(4, 3, r.nextInt(high - low) + low);
        arr.sumVal(5, 3, r.nextInt(high - low) + low);

        arr.sumVal(1, 4, r.nextInt(high - low) + low);
        arr.sumVal(2, 4, r.nextInt(high - low) + low);
        arr.sumVal(3, 4, r.nextInt(high - low) + low);
        arr.sumVal(4, 4, r.nextInt(high - low) + low);
        arr.sumVal(5, 4, r.nextInt(high - low) + low);

        arr.imprimir();
    }

    public static class Arreglo {

        int[][] arreglo = new int[5][4];

        public Arreglo() {
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 4; j++) {
                    this.arreglo[i][j] = 0;
                }
            }
        }

        public void sumVal(int vendedor, int producto, int val) {
            this.arreglo[vendedor - 1][producto - 1] += val;
        }

        public void imprimir() {
            int sumaFila;
            int[] sumaColumnas = {0, 0, 0, 0};

            System.out.printf("%-12s %-12s %-12s %-12s %-12s %-12s\n", "", "Vendedor 1", "Vendedor 2", "Vendedor 3", "Vendedor 4", "Totales");
            for (int i = 0; i < 5; i++) {
                sumaFila = 0;
                System.out.printf("%-8s %d   ", "Producto", i + 1);
                for (int j = 0; j < 4; j++) {
                    System.out.printf("%-12d ", this.arreglo[i][j]);
                    sumaFila += this.arreglo[i][j];
                    sumaColumnas[j] += this.arreglo[i][j];
                }
                //sumaColumnas[4] += sumaFila;
                System.out.printf("%-12d \n", sumaFila);
            }
            System.out.printf("%-12s ", "Totales");
            for (int i = 0; i < 4; i++) {
                System.out.printf("%-12d ", sumaColumnas[i]);
            }
            System.out.println();
        }
    }
}
